﻿//Program Title: Prove 1 - Tic-Tac-Toe
//Author: Michael Knudsen
//This is a somewhat challenging program that
//creates a two player game of Tic-Tac-Toe. Here I will
//demonstrate good use of if/else, loops, and management of variables.
//I also have to excercise dividing up the work among the different functions.



using System;
using System.Collections.Generic;

namespace ticTacToe
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> tableSpots = new List<string>();
            int turnCount = 0; //saves the number of turns that pass in the game
            //int* p = & turnCount; //declares a pointer
            bool gameEnd = false;

            Console.WriteLine("TIC TAC TOE!");
            Console.WriteLine("Player 1 places (x's) and Player 2 places (o's)");
            Console.WriteLine("Begin!");

            string[,] board = BuildBoard();
            DisplayBoard(board);
            
            while (turnCount < 9 && gameEnd == false)
            {
                board = PlayMove(board, turnCount);
                Console.WriteLine($"{turnCount} turns have passed!");
                DisplayBoard(board);
                gameEnd = CheckWin(board);
                turnCount++;

                if (turnCount > 8)
                {
                    Console.WriteLine("It was a draw! Thanks for playing!");
                }
            }
            

        }

        static string[,] BuildBoard()
        {
            string[,] board = new string[3,3] { {"1", "2", "3"}, {"4", "5", "6"}, {"7", "8", "9"} };
            return board;
        }
        static void DisplayBoard(string[,] board)
        {
            int counter = 0;

            for (int row = 0; row < 3; row++)
            {
                for (int col = 0; col < 3; col++)
                {
                    Console.Write(board[row,col]);
                    counter++;
                    if (col == 0 || col == 1)
                    {
                        Console.Write("|");
                    }
                }
                Console.WriteLine();
                if (row == 0 || row == 1)
                {
                    Console.WriteLine("-+-+--");
                }
            }
        }
        static string[,] PlayMove (string[,] board, int turnCount)
        {
            int tRow = 0;
            int tCol = 0;
            string current = CheckTurn(turnCount);

            Console.WriteLine($"It is {current}'s turn!");
            Console.WriteLine($"Place an '{current}' in spots (1 - 9): ");
            string newInput = Console.ReadLine();
            int tableSpot = int.Parse(newInput);
            //find the right Row
            if (tableSpot > 6 && tableSpot < 10)
            {
                tRow = 2;
            }
            else if (tableSpot > 3 && tableSpot < 7)
            {
                tRow = 1;
            }
            else if (tableSpot > 0 && tableSpot < 4)
            {
                tRow = 0;
            }
            //Console.WriteLine($"tRow equals: {tRow}");
            
            //find the right Column
            if (tableSpot == 3 || tableSpot == 6 || tableSpot == 9)
            {
                tCol = 2;
            }
            else if (tableSpot == 2 || tableSpot == 5 || tableSpot == 8)
            {
                tCol = 1;
            }
            else if (tableSpot == 1 || tableSpot == 4 || tableSpot == 7)
            {
                tCol = 0;
            }
            //Console.WriteLine($"tCol equals: {tCol}");

            if (board[tRow, tCol] == "X" || board[tRow, tCol] == "O")
            {
                Console.WriteLine($"Spot {tableSpot} is already filled!");
                turnCount--;
            }
            else
            {
                board[tRow, tCol] = current;
            }
            return board;
        }

        static string CheckTurn(int turnCount)
        {
            string player = "A";
            if (turnCount % 2 == 0)
            {
                player = "X";
            }
            else if (turnCount % 2 != 0)
            {
                player = "O";
            }
            return player;
        }

        static bool CheckWin(string[,] board)
        {
            bool winner = false;
            
            //checking if 'X' is the winner
            if (board[0, 0] == "X" && board[0, 1] == "X" && board[0, 2] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[1, 0] == "X" && board[1, 1] == "X" && board[1, 2] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[1, 0] == "X" && board[1, 1] == "X" && board[1, 2] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 0] == "X" && board[1, 1] == "X" && board[2, 2] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 2] == "X" && board[1, 1] == "X" && board[2, 0] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 0] == "X" && board[1, 0] == "X" && board[2, 0] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 1] == "X" && board[1, 1] == "X" && board[2, 1] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 2] == "X" && board[1, 2] == "X" && board[2, 2] == "X")
            {
                Console.WriteLine("Player 1 Wins! Thanks for playing!");
                winner = true;
            }

            //checking if 'O' is the winner
            if (board[0, 0] == "O" && board[0, 1] == "O" && board[0, 2] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[1, 0] == "O" && board[1, 1] == "O" && board[1, 2] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[1, 0] == "O" && board[1, 1] == "O" && board[1, 2] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 0] == "O" && board[1, 1] == "O" && board[2, 2] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 2] == "O" && board[1, 1] == "O" && board[2, 0] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 0] == "O" && board[1, 0] == "O" && board[2, 0] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 1] == "O" && board[1, 1] == "O" && board[2, 1] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }
            else if (board[0, 2] == "O" && board[1, 2] == "O" && board[2, 2] == "O")
            {
                Console.WriteLine("Player 2 Wins! Thanks for playing!");
                winner = true;
            }

            //Console.WriteLine($"Game Complete = {winner}");
            return winner;
        }
    }
}


